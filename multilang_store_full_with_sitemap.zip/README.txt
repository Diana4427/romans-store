Multilingual static e-commerce site (demo)
Folders:
- /en, /ru, /et  -> localized site root pages (index.html, product-*.html, checkout.html)
- /assets -> styles, app.js, logo.png, logo.svg, product SVGs
Notes:
- Cart uses localStorage; checkout is demo-only and does NOT process payments.
- To deploy: upload folder contents to any static host (Netlify, Vercel, GitHub Pages).
- Replace product SVGs with real photos named: solar.svg, bottle.svg, lamp.svg in /assets.